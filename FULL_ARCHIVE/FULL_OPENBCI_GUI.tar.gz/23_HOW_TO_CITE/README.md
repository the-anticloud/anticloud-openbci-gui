# 23 How To Cite

**Project:** OPENBCI_GUI
**Upstream:** https://github.com/openbci/OpenBCI_GUI

Content specific to OPENBCI_GUI in category BRAIN_COMPUTER_INTERFACE.
