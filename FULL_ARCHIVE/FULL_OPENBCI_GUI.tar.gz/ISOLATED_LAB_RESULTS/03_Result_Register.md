# Result Register

**Project:** OPENBCI_GUI

| Result | Pass Condition | Command | Observed | Status |
| --- | --- | --- | --- | --- |
| (none yet) | (define before running) | (verbatim) | (unrecorded) | NOT RUN |
