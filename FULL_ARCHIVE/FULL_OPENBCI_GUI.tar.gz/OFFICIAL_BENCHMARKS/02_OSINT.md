# OSINT Benchmark — OPENBCI_GUI

**Upstream:** https://github.com/openbci/OpenBCI_GUI

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
